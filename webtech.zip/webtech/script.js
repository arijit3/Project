let navButtons = document.querySelectorAll(".nav-btn");
let pages = document.querySelectorAll(".page");
 
navButtons.forEach(function(button) {
    button.addEventListener("click", function() {
 
        pages.forEach(function(page) {
            page.classList.remove("show");
        });
 
        navButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });
 
        let pageName = button.dataset.page;
 
        document.getElementById(pageName).classList.add("show");
 
        button.classList.add("active");
    });
});
 
 
let employeeForm = document.getElementById("employeeForm");
let employeeTable = document.getElementById("employeeTable");
let employeeId = 1;
 
employeeForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = employeeForm.querySelectorAll("input");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = employeeId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let actionCell = document.createElement("td");
 
    let deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.classList.add("delete-btn");
 
    deleteButton.addEventListener("click", function() {
        row.remove();
        updateDashboard();
    });
 
    actionCell.appendChild(deleteButton);
    row.appendChild(actionCell);
 
    employeeTable.appendChild(row);
 
    employeeForm.reset();
    updateDashboard();
});
 
 
let supervisorForm = document.getElementById("supervisorForm");
let supervisorTable = document.getElementById("supervisorTable");
let supervisorId = 1;
 
supervisorForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = supervisorForm.querySelectorAll("input");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = supervisorId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let cell = document.createElement("td");
    let button = document.createElement("button");
 
    button.textContent = "Delete";
    button.classList.add("delete-btn");
 
    button.addEventListener("click", function() {
        row.remove();
        updateDashboard();
    });
 
    cell.appendChild(button);
    row.appendChild(cell);
 
    supervisorTable.appendChild(row);
 
    supervisorForm.reset();
    updateDashboard();
});
 
 
let teamleaderForm = document.getElementById("teamleaderForm");
let teamleaderTable = document.getElementById("teamleaderTable");
let teamleaderId = 1;
 
teamleaderForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = teamleaderForm.querySelectorAll("input");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = teamleaderId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let cell = document.createElement("td");
    let button = document.createElement("button");
 
    button.textContent = "Delete";
    button.classList.add("delete-btn");
 
    button.addEventListener("click", function() {
        row.remove();
        updateDashboard();
    });
 
    cell.appendChild(button);
    row.appendChild(cell);
 
    teamleaderTable.appendChild(row);
 
    teamleaderForm.reset();
    updateDashboard();
});
 
 
let departmentForm = document.getElementById("departmentForm");
let departmentTable = document.getElementById("departmentTable");
let departmentId = 1;
 
departmentForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = departmentForm.querySelectorAll("input");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = departmentId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let cell = document.createElement("td");
    let button = document.createElement("button");
 
    button.textContent = "Delete";
    button.classList.add("delete-btn");
 
    button.addEventListener("click", function() {
        row.remove();
        updateDashboard();
    });
 
    cell.appendChild(button);
    row.appendChild(cell);
 
    departmentTable.appendChild(row);
 
    departmentForm.reset();
    updateDashboard();
});
 
 
let attendanceForm = document.getElementById("attendanceForm");
let attendanceTable = document.getElementById("attendanceTable");
let attendanceId = 1;
 
attendanceForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = attendanceForm.querySelectorAll("input, select");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = attendanceId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let cell = document.createElement("td");
    let button = document.createElement("button");
 
    button.textContent = "Delete";
    button.classList.add("delete-btn");
 
    button.addEventListener("click", function() {
        row.remove();
    });
 
    cell.appendChild(button);
    row.appendChild(cell);
 
    attendanceTable.appendChild(row);
 
    attendanceForm.reset();
});
 
 
let leaveForm = document.getElementById("leaveForm");
let leaveTable = document.getElementById("leaveTable");
let leaveId = 1;
 
leaveForm.addEventListener("submit", function(event) {
    event.preventDefault();
 
    let inputs = leaveForm.querySelectorAll("input");
    let row = document.createElement("tr");
 
    let idCell = document.createElement("td");
    idCell.textContent = leaveId++;
    row.appendChild(idCell);
 
    inputs.forEach(function(input) {
        let cell = document.createElement("td");
        cell.textContent = input.value;
        row.appendChild(cell);
    });
 
    let statusCell = document.createElement("td");
    statusCell.textContent = "Pending";
    row.appendChild(statusCell);
 
    let actionCell = document.createElement("td");
 
    let approveButton = document.createElement("button");
    approveButton.textContent = "Approve";
    approveButton.classList.add("approve-btn");
 
    approveButton.addEventListener("click", function() {
        statusCell.textContent = "Approved";
    });
 
    let rejectButton = document.createElement("button");
    rejectButton.textContent = "Reject";
    rejectButton.classList.add("reject-btn");
 
    rejectButton.addEventListener("click", function() {
        statusCell.textContent = "Rejected";
    });
 
    actionCell.appendChild(approveButton);
    actionCell.appendChild(rejectButton);
 
    row.appendChild(actionCell);
 
    leaveTable.appendChild(row);
 
    leaveForm.reset();
});
 
 
function updateDashboard() {
 
    document.getElementById("employeeCount").textContent =
        employeeTable.querySelectorAll("tr").length;
 
    document.getElementById("supervisorCount").textContent =
        supervisorTable.querySelectorAll("tr").length;
 
    document.getElementById("teamleaderCount").textContent =
        teamleaderTable.querySelectorAll("tr").length;
 
    document.getElementById("departmentCount").textContent =
        departmentTable.querySelectorAll("tr").length;
}
 
 
let employeeSearch = document.getElementById("employeeSearch");
 
employeeSearch.addEventListener("keyup", function() {
 
    let rows = employeeTable.querySelectorAll("tr");
 
    rows.forEach(function(row) {
 
        let name = row.textContent.toLowerCase();
        let search = employeeSearch.value.toLowerCase();
 
        if (name.includes(search)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
 
    });
 
});